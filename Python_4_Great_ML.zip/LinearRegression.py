#!/usr/bin/env python
# coding: utf-8

# # Linear Regression and Polynomial Regression on Boston Housing Dataset

# In[1]:


from sklearn.preprocessing import PolynomialFeatures
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_boston
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns

get_ipython().run_line_magic('matplotlib', 'inline')


# In[2]:


data = load_boston()


# We print the value of the data to understand what it contains. print(data.keys()) gives

# In[3]:


data.keys()


# - *data*: contains the information for various houses
# - *target*: prices of the house
# - *feature_names*: names of the features
# - *DESCR*: describes the dataset

# In[4]:


df = pd.DataFrame(data.data, columns=data.feature_names)


# In[5]:


df.head()


# In[6]:


df.describe()


# The prices of the house indicated by the variable MEDV is our target variable and the remaining are the feature variables based on which we will predict the value of a house.
# We will now load the data into a pandas dataframe using pd.DataFrame. We then print the first 5 rows of the data using head()

# ### Data preprocessing
# After loading the data, it’s a good practice to see if there are any missing values in the data. We count the number of missing values for each feature using isnull()
# 

# In[7]:


df['MEDV'] = data.target


# In[8]:


df.isnull().sum()


# However, there are no missing values in this dataset as shown above.

# ### Exploratory Data Analysis
# Exploratory Data Analysis is a very important step before training the model. In this section, we will use some visualizations to understand the relationship of the target variable with other features.
# Let’s first plot the distribution of the target variable MEDV. We will use the distplot function from the seaborn library.

# In[9]:


sns.set(rc={'figure.figsize':(11.7, 8.27)})
sns.distplot(df['MEDV'], bins=30)
plt.show()


# We see that the values of MEDV are distributed normally with few outliers.
# 
# 
# Next, we create a correlation matrix that measures the linear relationships between the variables. The correlation matrix can be formed by using the corr function from the pandas dataframe library. We will use the heatmap function from the seaborn library to plot the correlation matrix.

# In[10]:


correlation_matrix = df.corr().round(2)
# annot = True to print the values inside the square
sns.heatmap(data=correlation_matrix, annot=True)


# The correlation coefficient ranges from -1 to 1. If the value is close to 1, it means that there is a strong positive correlation between the two variables. When it is close to -1, the variables have a strong negative correlation.

# ## Observations:
# 
# - To fit a linear regression model, we select those features which have a high correlation with our target variable MEDV.  By looking at the correlation matrix we can see that RM has a strong positive correlation with MEDV (0.7) where as LSTAT has a high negative correlation with MEDV(-0.74).
# 
# 
# - An important point in selecting features for a linear regression model is to check for multi-co-linearity. The features RAD, TAX have a correlation of 0.91. These feature pairs are strongly correlated to each other. We should not select both these features together for training the model. Check this for an explanation. Same goes for the features DIS and AGE which have a correlation of -0.75.
# 
# 
# Based on the above observations we will RM and LSTAT as our features. Using a scatter plot let’s see how these features vary with MEDV.

# In[11]:


plt.figure(figsize=(20, 5))

features = ['LSTAT', 'RM']
target = df['MEDV']

for i, col in enumerate(features):
    plt.subplot(1, len(features) , i+1)
    x = df[col]
    y = target
    plt.scatter(x, y, marker='o')
    plt.title(col)
    plt.xlabel(col)
    plt.ylabel('MEDV')


# ### Observations:
# 
# - The prices increase as the value of RM increases linearly. There are few outliers and the data seems to be capped at 50.
# 
# - The prices tend to decrease with an increase in LSTAT. Though it doesn’t look to be following exactly a linear line.

# ### Preparing the data for training the model
# We concatenate the LSTAT and RM columns using np.c_ provided by the numpy library.

# In[12]:


X = pd.DataFrame(np.c_[df['LSTAT'], df['RM']], columns=['LSTAT', 'RM'])
Y = df['MEDV']


# In[13]:


print(X.shape)
print(Y.shape)


# ## Splitting the data into training and testing sets
# 
# Next, we split the data into training and testing sets. We train the model with 80% of the samples and test with the remaining 20%. We do this to assess the model’s performance on unseen data. To split the data we use train_test_split function provided by scikit-learn library. We finally print the sizes of our training and test set to verify if the splitting has occurred properly.

# In[14]:


X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.2, random_state=5)

print(X_train.shape)
print(X_test.shape)
print(Y_train.shape)
print(Y_test.shape)


# ## Training and testing the model
# We use scikit-learn’s LinearRegression to train our model on both the training and test sets.

# In[15]:


from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score


# Let’s apply a linear regression model to this dataset.

# In[16]:


lr_model = LinearRegression()
lr_model.fit(X_train, Y_train)


# ## Model evaluation
# We will evaluate our model using RMSE and R2-score.
# 

# In[17]:


# model evaluation for training set

y_train_predict = lr_model.predict(X_train)
rmse = (np.sqrt(mean_squared_error(Y_train, y_train_predict)))
r2 = r2_score(Y_train, y_train_predict)

print("The model performance for training set")
print("--------------------------------------")
print('RMSE is {}'.format(rmse))
print('R2 score is {}'.format(r2))
print("\n")

# model evaluation for testing set

y_test_predict = lr_model.predict(X_test)
# root mean square error of the model
rmse = (np.sqrt(mean_squared_error(Y_test, y_test_predict)))

# r-squared score of the model
r2 = r2_score(Y_test, y_test_predict)

print("The model performance for testing set")
print("--------------------------------------")
print('RMSE is {}'.format(rmse))
print('R2 score is {}'.format(r2))


# ## Visualize the Linear Regression Results

# In[18]:


# plotting the y_test vs y_pred
# ideally should have been a straight line
plt.scatter(Y_test, y_test_predict, c='red')
plt.show()


# In[19]:


def create_polynomial_regression_model(degree):
    "Creates a polynomial regression model for the given degree"

    poly_features = PolynomialFeatures(degree=degree)

    # transforms the existing features to higher degree features.
    X_train_poly = poly_features.fit_transform(X_train)

    # fit the transformed features to Linear Regression
    poly_model = LinearRegression()
    poly_model.fit(X_train_poly, Y_train)

    # predicting on training data-set
    y_train_predicted = poly_model.predict(X_train_poly)

    # predicting on test data-set
    y_test_predict = poly_model.predict(poly_features.fit_transform(X_test))

    # evaluating the model on training dataset
    rmse_train = np.sqrt(mean_squared_error(Y_train, y_train_predicted))
    r2_train = r2_score(Y_train, y_train_predicted)

    # evaluating the model on test dataset
    rmse_test = np.sqrt(mean_squared_error(Y_test, y_test_predict))
    r2_test = r2_score(Y_test, y_test_predict)

    print("The model performance for the training set")
    print("-------------------------------------------")
    print("RMSE of training set is {}".format(rmse_train))
    print("R2 score of training set is {}".format(r2_train))

    print("\n")

    print("The model performance for the test set")
    print("-------------------------------------------")
    print("RMSE of test set is {}".format(rmse_test))
    print("R2 score of test set is {}".format(r2_test))
    
    # plotting the y_test vs y_pred
    # ideally should have been a straight line
    plt.scatter(Y_test, y_test_predict, c='red')
    plt.show()


# In[20]:


create_polynomial_regression_model(2)


# ### We can observe that the error has reduced after using polynomial regression as compared to linear regression

# # Done.
